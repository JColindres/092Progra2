﻿Public Class FormResultados
    Private Sub Btn_Regresar_Click(sender As Object, e As EventArgs) Handles Btn_Regresar.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class